"""
Pipeline de classificação das normas pendentes.

Para cada linha do relatório:
  1. obtém o documento (JSON canônico da ingestão ou PDF lido agora) -> ficha
     (Leitor; cacheada por norma + hash do conteúdo)
  2. embedding da ficha -> k normas já classificadas mais semelhantes
  3. Classificador -> classificação por segmento + resumo + evidências
  4. validação em código: áreas da taxonomia, coerência aplicável/áreas/risco,
     referências citadas existem na estrutura da norma, trechos localizáveis;
     uma tentativa de correção se houver erro
  5. (opcional) segunda opinião do modelo Revisor nos casos difíceis
  6. regras de vigência -> uma ou mais linhas (parágrafo da vigência conferido)
  7. achata para o layout de colunas da planilha de saída

Uso:
  python pipeline.py --relatorio pendentes.xlsx --saida resultado.xlsx
"""
from __future__ import annotations

import argparse
import traceback
from pathlib import Path

import pandas as pd

import config
from base_conhecimento import IndiceSimilaridade, carregar_base, obter_ficha, texto_para_embedding
from prompts import PROMPT_VERSAO
from schemas import ClassificacaoNorma
from util import CacheFichas, extrair_meta, slug
from vigencia import expandir_vigencias

USAR_REVISOR = False  # ligue depois da avaliação, se os casos difíceis justificarem o custo


# ---------------------------------------------------------------- validação
def _corrigir_area(nome: str, validas: list[str]) -> str | None:
    """Tolera diferenças de acento/caixa; devolve o nome oficial ou None."""
    alvo = slug(nome)
    for v in validas:
        if slug(v) == alvo:
            return v
    return None


def validar_classificacao(cls: ClassificacaoNorma, tax: dict) -> list[str]:
    """Normaliza o que dá para normalizar e devolve a lista de erros restantes."""
    erros: list[str] = []
    for seg, c in cls.por_segmento().items():
        validas = config.areas_do_segmento(tax, seg)
        if c.aplicavel:
            corrigidas, invalidas = [], []
            for a in c.areas_impactadas:
                oficial = _corrigir_area(a, validas)
                (corrigidas if oficial else invalidas).append(oficial or a)
            c.areas_impactadas = list(dict.fromkeys(corrigidas))
            if invalidas:
                erros.append(f"{seg}: áreas fora da taxonomia {invalidas}; use apenas {validas}")
            if not c.areas_impactadas:
                erros.append(f"{seg}: marcado como aplicável sem nenhuma área válida")
            if c.risco is None:
                erros.append(f"{seg}: marcado como aplicável sem risco")
        else:
            c.areas_impactadas, c.risco = [], None  # não aplicável: campos vazios por regra
        if not c.comentario.strip():
            erros.append(f"{seg}: comentário vazio")
    for e in cls.evidencias:
        e.segmentos = [s for s in e.segmentos if s in config.SEGMENTOS]
    return erros


def validar_referencias(cls: ClassificacaoNorma, estrutura) -> tuple[list[str], list[str]]:
    """Confere as evidências contra a estrutura determinística da norma. Devolve (erros, avisos)."""
    erros, avisos = [], []
    if estrutura.vazia:
        return erros, ["Sem índice determinístico (documento digitalizado): referências não conferidas."]
    for e in cls.evidencias:
        nivel = estrutura.verificar_referencia(e.referencia)
        if nivel == "inexistente":
            msg = f"evidência cita '{e.referencia}', que não existe no índice de dispositivos; cite só referências do índice"
            (erros if config.EXIGIR_REFERENCIAS_VALIDAS else avisos).append(msg)
            continue
        if nivel == "parcial":
            avisos.append(f"'{e.referencia}' não corresponde exatamente a um dispositivo do índice (correspondência parcial)")
        if not estrutura.contem_trecho(e.trecho, e.referencia):
            avisos.append(f"trecho da evidência em '{e.referencia}' não foi localizado literalmente no texto")
    return erros, avisos


def renderizar_resumo(cls: ClassificacaoNorma) -> str:
    partes = [cls.resumo_analise.strip(), "", "Evidências (dispositivo → segmentos | áreas):"]
    for e in cls.evidencias:
        partes.append(
            f"- {e.referencia} → {', '.join(e.segmentos) or '-'} | {', '.join(e.areas) or '-'} — "
            f"{e.motivo} (trecho: \"{e.trecho}\")"
        )
    return "\n".join(partes)


# ------------------------------------------------------------- processamento
def processar_norma(row: pd.Series, cliente, indice: IndiceSimilaridade, tax: dict, cache: CacheFichas,
                    excluir_ids: set[str] | None = None) -> dict:
    meta = extrair_meta(row)
    ficha, doc = obter_ficha(meta, cliente, cache)

    vetor = cliente.embed([texto_para_embedding(meta, ficha)], task_type="RETRIEVAL_QUERY")[0]
    excluir = set(excluir_ids or set()) | {meta["id"]}  # a norma nunca é exemplo de si mesma
    exemplos = indice.montar_exemplos(indice.buscar(vetor, excluir_ids=excluir, orgao=meta.get("orgao")))

    cls = cliente.classificar(tax, exemplos, meta, ficha, doc)
    erros = validar_classificacao(cls, tax)
    erros_ref, avisos = validar_referencias(cls, doc.estrutura)
    erros += erros_ref
    if erros:  # uma única tentativa de correção, com os erros explicados
        cls = cliente.classificar(tax, exemplos, meta, ficha, doc, observacoes="\n".join(erros))
        erros = validar_classificacao(cls, tax)
        erros_ref, avisos = validar_referencias(cls, doc.estrutura)
        erros += erros_ref
    avisos += [f"parser: {a}" for a in doc.estrutura.avisos]

    alerta_revisor = ""
    if USAR_REVISOR and _caso_dificil(cls):
        segunda = cliente.classificar(tax, exemplos, meta, ficha, doc,
                                      modelo=config.MODELO_REVISOR, thinking_level=config.THINKING_REVISOR)
        validar_classificacao(segunda, tax)
        alerta_revisor = _comparar(cls, segunda)

    linhas_vigencia = expandir_vigencias(meta, ficha.vigencias)
    for lv in linhas_vigencia:  # o parágrafo apontado para a vigência precisa existir na norma
        ref = lv.get("paragrafo_vigencia")
        if ref and not doc.estrutura.vazia and doc.estrutura.verificar_referencia(ref) == "inexistente":
            lv["alerta_vigencia"] = (lv["alerta_vigencia"] + " | " if lv["alerta_vigencia"] else "") + \
                                    f"parágrafo '{ref}' não existe no índice de dispositivos"

    return {
        "meta": meta,
        "ficha": ficha,
        "documento": doc,
        "classificacao": cls,
        "exemplos": exemplos,
        "erros": erros,
        "avisos": avisos,
        "alerta_revisor": alerta_revisor,
        "linhas_vigencia": linhas_vigencia,
    }


def _caso_dificil(cls: ClassificacaoNorma) -> bool:
    return cls.confianca == "baixa" or any(c.risco == "alto" for c in cls.por_segmento().values())


def _comparar(a: ClassificacaoNorma, b: ClassificacaoNorma) -> str:
    divergencias = []
    for seg, ca in a.por_segmento().items():
        cb = b.por_segmento()[seg]
        if ca.aplicavel != cb.aplicavel or ca.risco != cb.risco or set(ca.areas_impactadas) != set(cb.areas_impactadas):
            divergencias.append(f"{seg}: classificador={ca.aplicavel}/{ca.risco}/{ca.areas_impactadas} "
                                f"revisor={cb.aplicavel}/{cb.risco}/{cb.areas_impactadas}")
    return "; ".join(divergencias)


# --------------------------------------------------------------- achatamento
def achatar(resultado: dict, row: pd.Series) -> list[dict]:
    """Uma linha de saída por linha de vigência, repetindo a classificação."""
    meta, cls, erros = resultado["meta"], resultado["classificacao"], resultado["erros"]
    suf = config.SUFIXOS_CLASSIFICACAO
    base = {col: row.get(col) for col in config.COLUNAS_ENTRADA.values() if col in row.index}
    base["ID_Norma"] = meta["id"]
    for seg, c in cls.por_segmento().items():
        base[f"{seg}_{suf['aplicavel']}"] = "Sim" if c.aplicavel else "Não"
        base[f"{seg}_{suf['areas']}"] = config.SEPARADOR_AREAS.join(c.areas_impactadas)
        base[f"{seg}_{suf['risco']}"] = c.risco or ""
        base[f"{seg}_{suf['comentario']}"] = c.comentario
        base[f"{seg}_Justificativa"] = c.justificativa_aplicabilidade
    base["Resumo_IA"] = renderizar_resumo(cls)
    base["Confianca_IA"] = cls.confianca
    base["Normas_Similares"] = "; ".join(cls.normas_similares_usadas)
    base["Exemplos_Recuperados"] = "; ".join(f"{e['id']} ({e['score']:.2f})" for e in resultado["exemplos"])
    revisar = (cls.confianca not in config.CONFIANCA_DISPENSA_REVISAO or erros or resultado["alerta_revisor"]
               or (config.AVISOS_FORCAM_REVISAO and resultado["avisos"]))
    base["Status_Revisao"] = "revisar" if revisar else "sugerido_auto"
    base["Erros_Validacao"] = "; ".join(erros)
    base["Avisos_Validacao"] = "; ".join(resultado["avisos"])
    base["Alerta_Revisor"] = resultado["alerta_revisor"]
    base["Modelo"] = config.MODELO_CLASSIFICADOR
    base["Versao_Prompt"] = PROMPT_VERSAO
    doc = resultado["documento"]
    base["Hash_Documento"] = doc.hash_conteudo
    base["Origem_Documento"] = doc.origem
    base["Versao_Documento"] = doc.versao
    base["Origem_Dispositivos"] = resultado["ficha"].origem_dispositivos

    linhas = []
    for lv in resultado["linhas_vigencia"]:
        linha = dict(base)
        linha.update({_titulo(k): v for k, v in lv.items()})
        linhas.append(linha)
    return linhas


def _titulo(chave: str) -> str:
    return "_".join(p.capitalize() for p in chave.split("_"))


def _linha_erro(row: pd.Series, erro: Exception) -> dict:
    linha = {col: row.get(col) for col in config.COLUNAS_ENTRADA.values() if col in row.index}
    linha["Status_Revisao"] = "erro_processamento"
    linha["Erros_Validacao"] = f"{type(erro).__name__}: {erro}"
    return linha


def _vigente(row: pd.Series) -> bool:
    situacao = str(row.get(config.COLUNAS_ENTRADA["situacao"], "")).strip().lower()
    return not situacao or situacao.startswith(("vig", "em vigor", "ativ"))


# ------------------------------------------------------------------- driver
def classificar_pendentes(df_relatorio: pd.DataFrame, cliente, indice: IndiceSimilaridade, tax: dict,
                          cache: CacheFichas | None = None, arq_parcial: Path | None = None) -> pd.DataFrame:
    cache = cache or CacheFichas()
    saida: list[dict] = []
    for i, (_, row) in enumerate(df_relatorio.iterrows(), start=1):
        if config.CLASSIFICAR_APENAS_VIGENTES and not _vigente(row):
            continue
        try:
            saida.extend(achatar(processar_norma(row, cliente, indice, tax, cache), row))
        except Exception as e:  # noqa: BLE001 - uma norma com erro não derruba o lote
            traceback.print_exc()
            saida.append(_linha_erro(row, e))
        if arq_parcial and i % 10 == 0:
            pd.DataFrame(saida).to_csv(arq_parcial, index=False)  # progresso salvo a cada 10 normas
        print(f"[{i}/{len(df_relatorio)}] {row.get(config.COLUNAS_ENTRADA['numero'])}")
    return pd.DataFrame(saida)


def _ler_tabela(caminho: str) -> pd.DataFrame:
    return pd.read_excel(caminho) if caminho.lower().endswith((".xlsx", ".xls")) else pd.read_csv(caminho)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--relatorio", required=True, help="xlsx/csv com as normas pendentes")
    ap.add_argument("--saida", required=True, help="xlsx/csv de saída")
    ap.add_argument("--base", default=str(config.ARQ_BASE_CONHECIMENTO))
    args = ap.parse_args()

    from llm import ClienteGemini

    cliente = ClienteGemini()
    tax = config.carregar_taxonomia()
    indice = IndiceSimilaridade(carregar_base(Path(args.base)))
    df = classificar_pendentes(_ler_tabela(args.relatorio), cliente, indice, tax,
                               arq_parcial=Path(args.saida).with_suffix(".parcial.csv"))
    if args.saida.lower().endswith(".xlsx"):
        df.to_excel(args.saida, index=False)
    else:
        df.to_csv(args.saida, index=False)
    print(f"Concluído: {len(df)} linhas em {args.saida}")
