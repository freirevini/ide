"""
Ponto de junção das duas trilhas.

Tudo que o Leitor e o Classificador precisam de uma norma está em DocumentoNorma:
texto, estrutura (dispositivos com referência exata), hash, versão e origem.
Quem produz esse objeto pode ser:

  Trilha A (hoje)   PDF -> PyMuPDF -> estrutura.parsear()           origem = "pymupdf"
                    PDF digitalizado -> bytes para o Gemini ler      origem = "pdf_digitalizado"
  Trilha B (ingestão) JSON canônico (Docling + parser LC 95) lido de
                    arquivo local, gs:// ou BigQuery                  origem = "json_canonico"

O restante do pipeline não sabe qual trilha produziu o documento.

Contrato do JSON canônico (ver ARQUITETURA.md):
{
  "id": "...", "versao": "original|consolidada", "hash_sha256": "...", "fonte": {"url": "...", "data_captura": "..."},
  "ferramenta": {"conversor": "docling x.y", "parser": "..."},
  "texto_markdown": "...",
  "dispositivos": [{"id": "d0001", "tipo": "artigo", "referencia": "Art. 1º", "texto": "...", "pai_id": null,
                    "pagina": 1, "citacao": false}],
  "tabelas": [...], "validacao": {"status": "ok|pendente", "avisos": []}
}
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import config
from estrutura import DispositivoEstruturado, EstruturaNorma, parsear
from leitura_pdf import extrair, ler_bytes


@dataclass
class DocumentoNorma:
    id: str
    hash_conteudo: str
    origem: str                 # pymupdf | pdf_digitalizado | json_canonico
    versao: str                 # original | consolidada | desconhecida
    fonte: str
    texto: str | None           # Markdown (trilha B) ou texto plano normalizado (trilha A)
    estrutura: EstruturaNorma
    bytes_pdf: bytes | None = None
    ferramenta: str = ""

    @property
    def texto_para_prompt(self) -> str | None:
        """Markdown com os dispositivos marcados; cai no texto bruto se a estrutura estiver vazia."""
        if self.estrutura.vazia:
            return self.texto
        return self.estrutura.para_markdown()


# ---------------------------------------------------------------- trilha B
def carregar_json_canonico(dados: dict, id_norma: str, fonte: str) -> DocumentoNorma:
    est = EstruturaNorma(origem="json_canonico", avisos=list(dados.get("validacao", {}).get("avisos", [])))
    for d in dados.get("dispositivos", []):
        est.dispositivos.append(DispositivoEstruturado(
            id=str(d.get("id")), tipo=d.get("tipo", "artigo"), referencia=d["referencia"], texto=d.get("texto", ""),
            pai_id=d.get("pai_id"), pagina=d.get("pagina"), citacao=bool(d.get("citacao", False)),
        ))
    texto = dados.get("texto_markdown") or "\n".join(d.texto for d in est.dispositivos)
    hash_ = dados.get("hash_sha256") or hashlib.sha256(texto.encode("utf-8")).hexdigest()
    ferramenta = dados.get("ferramenta") or {}
    return DocumentoNorma(
        id=dados.get("id") or id_norma, hash_conteudo=hash_, origem="json_canonico",
        versao=dados.get("versao", "desconhecida"), fonte=fonte, texto=texto, estrutura=est,
        ferramenta=", ".join(f"{k}={v}" for k, v in ferramenta.items()),
    )


def carregar_json_de_caminho(caminho: str, id_norma: str) -> DocumentoNorma:
    dados = json.loads(ler_bytes(caminho).decode("utf-8")) if caminho.startswith("gs://") else json.loads(Path(caminho).read_text(encoding="utf-8"))
    return carregar_json_canonico(dados, id_norma, caminho)


def carregar_json_bigquery(id_norma: str, versao: str = "original") -> DocumentoNorma | None:
    """Lê a coluna JSON `documento` da tabela `normativo` (fonte de verdade da camada de ingestão)."""
    from google.cloud import bigquery

    cliente = bigquery.Client(project=config.PROJECT_ID)
    sql = f"""
        SELECT TO_JSON_STRING(documento) AS doc
        FROM `{config.TABELA_NORMATIVO}`
        WHERE id = @id AND versao = @versao
        ORDER BY data_captura DESC LIMIT 1
    """
    job = cliente.query(sql, job_config=bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("id", "STRING", id_norma),
        bigquery.ScalarQueryParameter("versao", "STRING", versao),
    ]))
    linhas = list(job.result())
    if not linhas:
        return None
    return carregar_json_canonico(json.loads(linhas[0]["doc"]), id_norma, f"bigquery:{config.TABELA_NORMATIVO}")


# ---------------------------------------------------------------- trilha A
def carregar_pdf(caminho: str, id_norma: str) -> DocumentoNorma:
    conteudo = extrair(caminho)
    if conteudo.texto is None:
        est = EstruturaNorma(origem="vazia", avisos=["PDF digitalizado: sem camada de texto; dispositivos virão do Leitor."])
        return DocumentoNorma(id_norma, conteudo.hash_conteudo, "pdf_digitalizado", "desconhecida", caminho, None, est,
                              bytes_pdf=conteudo.bytes_pdf, ferramenta="gemini-pdf")
    est = parsear(conteudo.texto)
    return DocumentoNorma(id_norma, conteudo.hash_conteudo, "pymupdf", "desconhecida", caminho, conteudo.texto, est,
                          ferramenta="pymupdf+estrutura.parsear")


# ------------------------------------------------------------------ fachada
def obter_documento(meta: dict) -> DocumentoNorma:
    """Escolhe a fonte pela linha do relatório: JSON canônico > BigQuery > PDF."""
    if meta.get("documento_json"):
        doc = carregar_json_de_caminho(meta["documento_json"], meta["id"])
    elif config.USAR_BIGQUERY_NORMATIVO and (doc := carregar_json_bigquery(meta["id"], config.VERSAO_PARA_CLASSIFICAR)):
        pass
    elif meta.get("caminho_pdf"):
        doc = carregar_pdf(meta["caminho_pdf"], meta["id"])
    else:
        raise ValueError(f"Norma {meta['id']}: sem 'Documento JSON', sem registro no BigQuery e sem 'Caminho PDF'.")
    if meta.get("versao") and doc.versao == "desconhecida":
        doc.versao = str(meta["versao"]).strip().lower()
    return doc
