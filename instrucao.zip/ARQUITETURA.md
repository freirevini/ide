# Arquitetura consolidada — ingestão e classificação de normas regulatórias

Este documento consolida as duas estratégias discutidas: a **camada de ingestão**
(PDF → JSON canônico validado) e a **camada de classificação** (LLM com exemplos
humanos → sugestão por segmento). As duas se encontram em um único contrato: o
objeto `DocumentoNorma` (texto + dispositivos com referência exata + hash + versão).

```
            CAMADA DE INGESTÃO (trilha B)                     CAMADA DE CLASSIFICAÇÃO
 ┌──────────────────────────────────────────────┐   ┌──────────────────────────────────────────────┐
 │ 1 captura: link → PDF → SHA-256 → GCS         │   │ 5 Leitor (Gemini Flash): ficha + vigências    │
 │ 2 Docling: texto, tabelas, página/posição     │   │ 6 embedding da ficha → k exemplos humanos     │
 │ 3 parser LC 95: árvore de dispositivos,       │──▶│ 7 Classificador (Gemini): 4 segmentos +       │
 │   citações marcadas, vigência localizada      │   │   resumo com Art./§ + evidências              │
 │ 4 validação determinística; Gemini como       │   │ 8 validação em código (áreas, referências,    │
 │   segundo leitor só em tabelas/pendências     │   │   trechos, vigência) → linhas → revisão       │
 │ → BigQuery normativo.documento (JSON)         │   │ → classificacao_sugerida → humano → base      │
 └──────────────────────────────────────────────┘   └──────────────────────────────────────────────┘
                     ▲                                                   ▲
                     │ trilha A (hoje): PDF → PyMuPDF → estrutura.parsear() entrega o mesmo DocumentoNorma
```

## 1. Decisões de arquitetura

| # | Decisão | Por quê |
|---|---|---|
| DA-01 | O **JSON canônico** (`normativo.documento`) é a fonte de verdade. Markdown, tabelas planas, trechos para RAG, prompts e o índice de dispositivos são todos derivados dele, nunca o contrário. | Uma única origem evita divergência entre o que o analista vê, o que a LLM leu e o que está no banco. |
| DA-02 | **PDF original armazenado** no Cloud Storage (recomendado). Alternativa, se houver restrição de política: guardar só hash SHA-256 + link + data de captura e **re-baixar** para revalidar. | A validação posicional (células) e o segundo leitor por imagem da página só rodam com o PDF. O hash prova que o re-download é o mesmo arquivo. Custo de guardar é irrisório; valor de auditoria é alto. |
| DA-03 | Campo **`versao`** obrigatório: `original` (texto como publicado) ou `consolidada` (com alterações posteriores). A **classificação usa a `original`**; o agente/RAG usa a `consolidada`. | A página "exibenormativo" do BCB mostra texto consolidado com marcações "(Redação dada… pela Resolução…)"; os PDFs distinguem `v1_O` (original) de versões posteriores. Classificar uma norma nova sobre texto consolidado mistura impactos de normas diferentes. |
| DA-04 | **Determinismo declarado**: Docling e parser com versões fixadas e gravadas em `ferramenta`; nada de "regras" sem versão. | Docling usa modelos de ML (layout, tabelas); só é reprodutível com versão e pesos fixados. |
| DA-05 | A **LLM nunca corrige nem reescreve** texto. Leitor extrai; Classificador classifica; segundo leitor (tabelas/pendências) só devolve veredito em formato fixo. Divergência vira pendência humana. | Mantém a cadeia de custódia do texto: tudo que está no banco veio do arquivo por um caminho verificável. |
| DA-06 | **Referências só do índice determinístico.** A LLM escolhe entre referências que o parser gerou; o código confere cada referência e trecho citados nas evidências e no parágrafo de vigência. | Era o ponto mais frágil do resumo para o analista: a referência errada ao parágrafo. |
| DA-07 | **Controle do modelo por schema + thinking level**, não por temperatura. | Os Gemini recentes (3.x e 4 Argon) ignoram `temperature`, `top_p` e `top_k`. |
| DA-08 | **Validação determinística é o controle principal**; falha de validação vira **pendência**, nunca bloqueio do lote. | Um anexo fora do padrão não pode parar a ingestão do dia. |
| DA-09 | **Humano decide.** A LLM sugere; `sugerido_auto` só com confiança alta e zero erro de validação; toda correção humana realimenta a base de exemplos. | O padrão da equipe é o ativo; a LLM o replica e o sistema melhora a cada ciclo. |
| DA-10 | **Duas trilhas, uma interface.** A classificação roda hoje com PyMuPDF + parser de regras (trilha A) e troca a fonte pelo JSON canônico (trilha B) sem mudar o resto. | A ingestão completa é trabalho de semanas; a classificação não precisa esperar. |

## 2. Fluxo ponta a ponta

| Passo | Componente | Entrada → Saída | Determinístico? |
|---|---|---|---|
| 1 | Captura | link → PDF, SHA-256, data, versão (GCS + `normativo`) | sim |
| 2 | Docling (fixado) | PDF → texto, tabelas, página/coordenadas (JSON intermediário) | sim (dada a versão) |
| 3 | Parser LC 95 | JSON intermediário → árvore de dispositivos, citações marcadas, candidatos a vigência | sim |
| 4 | Validação de ingestão | texto round-trip, numeração, células × posição no PDF, colunas numéricas; Gemini só em tabelas/pendências | sim + veredito LLM |
| 5 | Leitor (`llm.gerar_ficha`) | metadados + índice + candidatos + texto → `FichaLeitor` (objeto, destinatários, obrigações, prazos, vigências, resumo) | LLM com schema |
| 6 | Base de conhecimento | ficha → embedding → k normas humanas mais parecidas (`IndiceSimilaridade`) | sim |
| 7 | Classificador (`llm.classificar`) | taxonomia + exemplos + ficha + índice + texto → `ClassificacaoNorma` (4 segmentos, resumo, evidências, confiança) | LLM com schema |
| 8 | Validação de classificação (`pipeline`) | áreas da taxonomia, coerência aplicável/áreas/risco, referências e trechos, parágrafo de vigência; 1 tentativa de correção | sim |
| 9 | Vigência (`vigencia.py`) | datas encontradas × colunas do relatório → 1..n linhas | sim |
| 10 | Saída e revisão | `classificacao_sugerida` / planilha; analista aprova ou corrige; `preparar_base.py` incorpora | humano |

Trilha A substitui os passos 1–4 por: PDF → PyMuPDF → `estrutura.parsear()` (mesmo contrato, sem página/coordenadas, avisos do parser gravados em `Avisos_Validacao`).

## 3. Modelo de dados (BigQuery)

```sql
-- Fonte de verdade da ingestão
CREATE TABLE normativos.normativo (
  id            STRING NOT NULL,     -- "ORGAO|TIPO|NUMERO" (util.id_norma)
  orgao         STRING, tipo STRING, numero STRING,
  data_publicacao DATE,
  versao        STRING NOT NULL,     -- original | consolidada
  hash_sha256   STRING NOT NULL,
  fonte_url     STRING, data_captura TIMESTAMP,
  gcs_pdf       STRING, gcs_json_intermediario STRING,
  ferramenta    JSON,                -- {"conversor": "docling 2.x", "parser": "lc95 1.0"}
  validacao     JSON,                -- {"status": "ok|pendente", "avisos": [...]}
  documento     JSON NOT NULL        -- contrato da seção 4
);

-- Tabelas planas derivadas (análise convencional e validação de referências)
CREATE TABLE normativos.dispositivo (
  id_norma STRING, versao STRING, id_dispositivo STRING, tipo STRING,
  referencia STRING, texto STRING, pai_id STRING, pagina INT64, citacao BOOL, ordem INT64
);
CREATE TABLE normativos.celula (
  id_norma STRING, versao STRING, id_tabela STRING, pagina INT64,
  linha INT64, coluna INT64, texto STRING, valor_numerico FLOAT64, bbox ARRAY<FLOAT64>
);

-- Classificação
CREATE TABLE normativos.base_conhecimento (        -- = base_conhecimento.parquet
  id STRING, hash_conteudo STRING, versao_documento STRING, origem_documento STRING,
  ficha_json JSON, texto_embedding STRING, embedding ARRAY<FLOAT64>, classificacao_json JSON
);
CREATE TABLE normativos.classificacao_sugerida (   -- = planilha de saída do pipeline
  id_norma STRING, tipo_linha STRING, status_vigencia STRING, vigencia_ia DATE, paragrafo_vigencia STRING,
  corporativo JSON, atacado JSON, varejo JSON, plataforma JSON,
  resumo_ia STRING, confianca_ia STRING, normas_similares STRING,
  status_revisao STRING, erros_validacao STRING, avisos_validacao STRING,
  modelo STRING, versao_prompt STRING, hash_documento STRING, origem_documento STRING, processado_em TIMESTAMP
);
```

Cloud Storage: `gs://<bucket>/normativos/pdf/<hash>.pdf` e `gs://<bucket>/normativos/json/<hash>.json`.
Quando a base passar de alguns milhares de normas: `CREATE VECTOR INDEX` sobre
`base_conhecimento.embedding` e `VECTOR_SEARCH` no lugar da busca em memória.

## 4. Contrato do JSON canônico (`normativo.documento`)

| Campo | Tipo | Obrigatório | Observação |
|---|---|---|---|
| `id` | string | sim | mesmo `id` de `util.id_norma` |
| `versao` | `original` \| `consolidada` | sim | ver DA-03 |
| `hash_sha256` | string | sim | hash do PDF de origem |
| `fonte` | `{url, data_captura}` | sim | |
| `ferramenta` | `{conversor, parser}` | sim | versões fixadas (DA-04) |
| `texto_markdown` | string | sim | gerado a partir dos dispositivos; é o que a LLM lê |
| `dispositivos[]` | lista | sim | ver abaixo |
| `tabelas[]` | lista | não | `{id, pagina, dispositivo_id, cabecalho[], linhas[][], bbox}` |
| `validacao` | `{status, avisos[]}` | sim | resultado do passo 4 |

Cada dispositivo: `{id, tipo, referencia, texto, pai_id, pagina, citacao}` com
`tipo ∈ {preambulo, divisao, anexo, artigo, paragrafo, paragrafo_unico, inciso, alinea, item, citacao, rodape}`
e `referencia` no formato do parser (`"Art. 5º, § 2º, inciso III, alínea a"`, `"Anexo I, Art. 1º"`).
Exemplo completo: `exemplos/documento_exemplo.json`. Leitor de referência: `documento.carregar_json_canonico`.

## 5. Validações

**Ingestão (passo 4):** texto da árvore == texto extraído (após normalização de espaços,
hifenização e caracteres `º § ª`); numeração de artigos crescente (lacunas legítimas por
revogação viram aviso, não erro); texto de cada célula == caracteres do PDF naquela posição;
colunas numéricas parseáveis; blocos de citação com início e fim marcados.

**Classificação (passo 8, `pipeline.py`):**
- quatro segmentos sempre presentes (schema); não aplicável ⇒ áreas vazias e risco nulo (código);
- áreas somente da taxonomia do segmento (tolerância a acento/caixa; o resto é erro);
- cada evidência cita referência que **existe** no índice (`exata`); correspondência `parcial`
  vira aviso; inexistente vira erro e pede correção uma vez;
- trecho literal da evidência localizável no dispositivo citado (aviso se não);
- parágrafo da vigência existe no índice (alerta na linha de vigência se não);
- `Status_Revisao = sugerido_auto` só com confiança alta, zero erro e, se configurado, zero aviso.

## 6. Regras de vigência (`vigencia.py`)

| Situação | Status | Linhas geradas |
|---|---|---|
| norma e relatório dizem a mesma data | `confirmada` | 1 |
| norma diz data diferente da coluna | `divergente` | original + `vigencia_adicional` (data, parágrafo, origem) |
| coluna vazia, norma informa a data | `identificada_sem_coluna` | original + `vigencia_adicional` |
| várias datas (vigência por partes) | `escalonada` | original + uma por data adicional, com dispositivos abrangidos |
| relatório informa, norma não traz data | `nao_confirmada` | 1, com alerta |
| ninguém informa | `nao_identificada` | 1, com alerta |

"Entra em vigor na data da publicação" na coluna textual conta como data = data de publicação.
`MANTER_LINHA_ORIGINAL_AO_DUPLICAR` controla se a linha original é preservada.

## 7. Segurança e auditoria

- Todo texto de norma e de exemplo entra nos prompts entre delimitadores e é declarado como
  dado; instruções dentro do documento não são obedecidas.
- Cada linha sugerida grava: `Modelo`, `Versao_Prompt`, `Hash_Documento`, `Origem_Documento`,
  `Versao_Documento`, `Origem_Dispositivos`, `Exemplos_Recuperados` (ids + scores). Com isso
  qualquer sugestão pode ser reproduzida e explicada.
- Nenhuma chave no código: ADC (`gcloud auth application-default login`) ou conta de serviço.

## 8. Pendências de decisão (preencher com a equipe)

- [ ] Guardar o PDF original (DA-02) ou só hash + link?
- [ ] Formato da saída: largo (4 colunas por segmento) ou longo (1 linha por norma × segmento)?
- [ ] Linha original preservada na duplicação por vigência?
- [ ] Política em dúvida de aplicabilidade: marcar aplicável/baixo/confiança baixa (atual) ou não aplicável?
- [ ] Taxonomia real: áreas por segmento com definição e critérios de risco (`taxonomia.yaml`).
- [ ] Ligar o Revisor (Argon) para confiança baixa / risco alto após a avaliação?
- [ ] Para séries recentes do BCB, parser sobre o HTML do "exibenormativo" em vez de Docling?
