# Classificador de normas — implementação de referência (consolidada)

Classifica normas regulatórias (BACEN, CMN, Min. Fazenda etc.) para quatro segmentos
(Corporativo, Atacado, Varejo, Plataforma) usando Gemini na Gemini Enterprise Agent
Platform (antigo Vertex AI). As normas já classificadas por humanos servem de exemplos
recuperados por similaridade; as referências a artigos e parágrafos vêm de um índice
determinístico e são conferidas em código.

A arquitetura completa (duas camadas, decisões, modelo de dados, contrato do JSON
canônico, validações, regras de vigência) está em **ARQUITETURA.md**. Este README é o
roteiro operacional.

## Como os arquivos se encaixam

| Arquivo | Papel |
|---|---|
| `ARQUITETURA.md` | Decisões, fluxo ponta a ponta, tabelas BigQuery, contrato do JSON canônico |
| `config.py` | Projeto, modelos, k, limiares, nomes de colunas, flags das duas trilhas |
| `taxonomia.yaml` | Segmentos, áreas por segmento (com definição) e critérios de risco — **substitua o exemplo** |
| `schemas.py` | Formato JSON que a LLM é obrigada a devolver (`FichaLeitor`, `ClassificacaoNorma`) |
| `prompts.py` | Os dois prompts (Leitor e Classificador) e a montagem dos blocos |
| `estrutura.py` | Parser de regras LC 95: dispositivos com referência exata, citações, vigência, conferência de referências |
| `documento.py` | Ponto de junção: `DocumentoNorma` a partir de PDF (trilha A) ou JSON canônico/BigQuery (trilha B) |
| `leitura_pdf.py` | Extração de texto (PyMuPDF) e detecção de PDF digitalizado |
| `llm.py` | Chamadas ao Gemini: ficha, classificação, embedding (com retry) |
| `util.py` | IDs, leitura das colunas, parse da classificação humana, cache de fichas |
| `base_conhecimento.py` | Base de normas classificadas: fichas + embeddings + busca por similaridade |
| `vigencia.py` | Regras de vigência: confirma, diverge, duplica linha, escalonada |
| `pipeline.py` | Orquestra tudo para o relatório de pendentes e gera a planilha de saída |
| `preparar_base.py` | Roda uma vez (e a cada ciclo): constrói a base de conhecimento |
| `avaliacao.py` | Hold-out: mede a concordância com os humanos antes de usar em produção |
| `exemplos/` | `norma_exemplo.txt` (texto no padrão BACEN) e `documento_exemplo.json` (contrato da ingestão) |
| `tests/test_logica.py` | 16 testes da lógica, com um cliente falso (sem nuvem) |

## 1. Ambiente (uma vez)

```bash
gcloud auth application-default login          # credenciais da sua conta na máquina
gcloud config set project SEU_PROJETO_GCP
gcloud services enable aiplatform.googleapis.com storage.googleapis.com bigquery.googleapis.com

python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export GCP_PROJECT=SEU_PROJETO_GCP                 # ou edite config.py
pytest -q                                          # deve passar sem nuvem
python -c "from estrutura import parsear; e=parsear(open('exemplos/norma_exemplo.txt').read()); print(e.para_markdown())"
```

Papéis no projeto: `Vertex AI User` (modelos); `Storage Object Viewer` se os PDFs/JSONs
estiverem no Cloud Storage; `BigQuery Data Viewer` se `USAR_BIGQUERY_NORMATIVO = True`.

## 2. Preparar dados

1. Planilha das normas **já classificadas**: colunas do relatório (`Órgão Regulador`, `Tipo`,
   `Número`, `Data da publicação do normativo`, `Ementa`, `Situação`, `Data de Início de Vigência`,
   `Vigência`) + fonte do texto (ver 2.1) + por segmento: `Corporativo_Aplicavel`,
   `Corporativo_Areas` (separadas por `;`), `Corporativo_Risco`, `Corporativo_Comentario`
   (idem Atacado, Varejo, Plataforma). Nomes diferentes → ajuste `COLUNAS_ENTRADA` e
   `SUFIXOS_CLASSIFICACAO` em `config.py`.
2. Planilha das normas **pendentes**: mesmas colunas do relatório + fonte do texto.
3. `taxonomia.yaml`: nomes de área **idênticos** aos da planilha classificada.

### 2.1 Fonte do texto da norma (as duas trilhas)

| Trilha | Coluna na planilha | O que acontece |
|---|---|---|
| A — hoje | `Caminho PDF` (local ou `gs://`) | PyMuPDF extrai o texto; `estrutura.parsear()` gera o índice de dispositivos; PDF digitalizado vai inteiro ao Gemini |
| B — ingestão | `Documento JSON` (local ou `gs://`), ou `USAR_BIGQUERY_NORMATIVO = True` | JSON canônico (Docling + parser LC 95) já traz dispositivos, páginas, versão e hash |

Prioridade: `Documento JSON` > BigQuery > `Caminho PDF`. A coluna opcional `Versão`
(`original`/`consolidada`) só é usada quando o JSON não a informa. A classificação deve
rodar sobre o texto **original** (`VERSAO_PARA_CLASSIFICAR`).

## 3. Rodar, nesta ordem

```bash
python preparar_base.py --classificadas base_classificada.xlsx            # fichas + embeddings
python avaliacao.py --classificadas base_classificada.xlsx --fracao 0.15  # métricas por segmento
python pipeline.py --relatorio pendentes.xlsx --saida resultado.xlsx      # produção
```

Leia as métricas antes de rodar em produção. Referências para liberar: recall de "aplicável"
alto (norma aplicável que passa batida é o erro caro), acurácia de risco acima do que a equipe
aceita e matriz de confusão sem trocas "baixo" ↔ "alto". Ajuste, nesta ordem: definições das
áreas na taxonomia → critérios de risco → `K_SIMILARES` → prompts → `THINKING_CLASSIFICADOR`
→ modelo.

## 4. Saída

Uma linha por norma, mais uma linha por vigência adicional encontrada no texto
(`Tipo_Linha` = `original` ou `vigencia_adicional`; `Status_Vigencia`, `Vigencia_Ia`,
`Paragrafo_Vigencia`, `Origem_Vigencia`, `Escopo_Vigencia`, `Alerta_Vigencia`). Para cada
segmento: `_Aplicavel`, `_Areas`, `_Risco`, `_Comentario`, `_Justificativa`. Mais:
`Resumo_IA` (análise + evidências com Art./§ conferidos), `Confianca_IA`, `Normas_Similares`,
`Exemplos_Recuperados`, `Status_Revisao` (`sugerido_auto` / `revisar` / `erro_processamento`),
`Erros_Validacao`, `Avisos_Validacao`, `Modelo`, `Versao_Prompt`, `Hash_Documento`,
`Origem_Documento`, `Versao_Documento`, `Origem_Dispositivos`.

## 5. Plano consolidado por fases

| Fase | Trilha | O quê | Como verificar |
|---|---|---|---|
| 0 | ambas | Ambiente (seção 1) | `pytest -q` verde |
| 1 | ambas | Planilhas + `taxonomia.yaml` real; decisões pendentes da seção 8 de ARQUITETURA.md | áreas da planilha == áreas do YAML |
| 2 | A | Leitor em 20 normas: conferir fichas em `cache/fichas/` (objeto, obrigações com referência do índice, vigências com parágrafo) | referências batem com o índice; vigências certas |
| 3 | A | `preparar_base.py` completo | `base_conhecimento.parquet` com todas as normas |
| 4 | A | Classificador em 20 pendentes; ler `resultado.xlsx`, em especial `Resumo_IA` e `Avisos_Validacao` | evidências apontam para os parágrafos certos |
| 5 | A | `avaliacao.py` (hold-out 15 %) e ajustes | métricas aceitas pela equipe |
| 6 | A | Produção + fila de revisão; ciclo semanal `preparar_base.py` | `sugerido_auto` cresce a cada ciclo |
| 7 | B | Ingestão: captura + Docling fixado + parser LC 95 + validação determinística + Gemini segundo leitor (tabelas/pendências) → `normativo.documento` | round-trip de texto e células validadas; pendências listadas |
| 8 | junção | Preencher `Documento JSON` (ou ligar `USAR_BIGQUERY_NORMATIVO`); rodar a avaliação de novo sobre a trilha B | `Origem_Documento = json_canonico`; métricas iguais ou melhores; `Avisos_Validacao` menor |
| 9 | ambas | Revisor (Argon) nos casos difíceis, Batch API para backlog, cache de contexto, `VECTOR_SEARCH` | custo/latência medidos |

A trilha B é um ganho de precisão de referência e de reuso (RAG, agente, análise), não um
pré-requisito: a classificação já funciona na trilha A e troca a fonte sem alterar o resto.

## 6. Ciclo de melhoria

Depois da revisão humana, acrescente as linhas aprovadas/corrigidas à planilha classificada
e rode `preparar_base.py` de novo. O cache em `cache/fichas/` (chave: id + hash do conteúdo)
evita reler normas já processadas; só as novas custam.

## 7. Escalar

- **Busca vetorial no BigQuery:** carregue o parquet em `normativos.base_conhecimento`, crie
  `VECTOR INDEX` e troque `IndiceSimilaridade.buscar` por `VECTOR_SEARCH(... top_k = K_SIMILARES)`.
- **Batch API:** para backlog grande, monte as requisições em tabela/JSONL e use o modo batch
  do modelo (metade do preço, sem limite de taxa online).
- **Context caching:** taxonomia + instruções + um exemplo canônico por área em cache de
  contexto; `cached_content` na chamada (confira na doc do modelo se o cache é explícito ou implícito).
- **Revisor:** `USAR_REVISOR = True` em `pipeline.py` para segunda opinião do `MODELO_REVISOR`
  em confiança baixa ou risco alto.
