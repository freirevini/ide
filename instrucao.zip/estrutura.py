"""
Camada canônica mínima: parser de regras (LC 95/1998) sobre o texto de uma norma.

Transforma texto corrido em DISPOSITIVOS com referência exata (capítulo, artigo,
parágrafo, inciso, alínea, anexo), marca como CITAÇÃO os trechos que apenas
reproduzem a redação dada a outra norma ("passa a vigorar com a seguinte
redação: ..."), localiza os candidatos a dispositivo de vigência e confere se
as referências que a LLM cita existem de fato.

Serve a duas fontes:
  - texto extraído do PDF pelo PyMuPDF (trilha A, disponível hoje);
  - JSON canônico da camada de ingestão (trilha B, Docling + parser completo),
    caso em que os dispositivos já chegam prontos e só a classe EstruturaNorma
    é usada (ver documento.py).

Não é um parser jurídico completo: é determinístico, testável e cobre o padrão
dos normativos BACEN/CMN/Fazenda. O que ele não entende vira aviso, não erro.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

ROMANO = r"(?=[IVXLCDM])M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})"

RE_DIVISAO = re.compile(
    r"^\s*(LIVRO|T[ÍI]TULO|CAP[ÍI]TULO|SE[ÇC][ÃA]O|SUBSE[ÇC][ÃA]O)\s+([IVXLCDM]+|[ÚU]NICO|\d+)\b\s*[-–:]?\s*(.*)$",
    re.IGNORECASE,
)
RE_ANEXO = re.compile(r"^\s*ANEXO\s*([IVXLCDM]+|[A-Z]|\d+)?\b\s*[-–:]?\s*(.*)$")
RE_ARTIGO = re.compile(r"^\s*Art(?:igo)?\.?\s*(\d+)\s*[ºo°]?\s*(-\s*[A-Z])?\s*[.\-–:]?\s*(.*)$")
RE_PARAGRAFO = re.compile(r"^\s*§\s*(\d+)\s*[ºo°]?\s*[.\-–:]?\s*(.*)$")
RE_PAR_UNICO = re.compile(r"^\s*Par[áa]grafo\s+[úu]nico\s*[.\-–:]?\s*(.*)$", re.IGNORECASE)
RE_INCISO = re.compile(rf"^\s*({ROMANO})\s*[-–]\s+(.*)$")
RE_ALINEA = re.compile(r"^\s*([a-z])\)\s+(.*)$")
RE_ITEM = re.compile(r"^\s*(\d{1,2})\.\s+(.*)$")
RE_RODAPE = re.compile(
    r"^\s*(Este texto n[ãa]o substitui|Diretor|Diretora|Presidente|Ministro|Ministra|Chefe|Secret[áa]rio|Secret[áa]ria)\b"
)
RE_NOME_CAIXA_ALTA = re.compile(r"^[A-ZÀ-Ú][A-ZÀ-Ú .'\-]{8,70}$")
RE_CITACAO_INICIO = re.compile(
    r"(vigorar\s+com\s+a[s]?\s+seguinte[s]?\s+(reda[çc][ãa]o|altera[çc][õo]es)"
    r"|acrescid[oa]s?\s+d[oa]s?\s+seguinte"
    r"|passa[m]?\s+a\s+vigorar\s+acrescid"
    r"|seguinte[s]?\s+(dispositivo|artigo|par[áa]grafo|inciso|al[íi]nea)s?\s*:\s*$"
    r"|reda[çc][ãa]o\s*:\s*$)",
    re.IGNORECASE,
)
RE_CITACAO_FIM = re.compile(r"(\(\s*(NR|AC)\s*\)\s*\.?\s*$|[”\"]\s*\.?\s*$)")
RE_VIGENCIA = re.compile(r"(entra[m]?\s+em\s+vigor|produz(?:ir[áa]|em|ir[ãa]o)?\s+efeitos|vig[êe]ncia)", re.IGNORECASE)
RE_REVOGA = re.compile(r"\brevoga", re.IGNORECASE)
RE_ALTERA = re.compile(r"(\baltera[mr]?\b|passa[m]?\s+a\s+vigorar)", re.IGNORECASE)

NIVEIS_CITAVEIS = {"artigo", "paragrafo", "paragrafo_unico", "inciso", "alinea", "item"}


@dataclass
class DispositivoEstruturado:
    id: str
    tipo: str                 # divisao | anexo | preambulo | artigo | paragrafo | paragrafo_unico | inciso | alinea | item | citacao | rodape
    referencia: str           # "Art. 5º, § 2º, inciso III"
    texto: str
    pai_id: str | None = None
    pagina: int | None = None
    citacao: bool = False

    @property
    def resumo(self) -> str:
        t = " ".join(self.texto.split())
        return t if len(t) <= 160 else t[:157] + "..."


@dataclass
class EstruturaNorma:
    dispositivos: list[DispositivoEstruturado] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)
    origem: str = "parser"    # parser | json_canonico | vazia

    # ------------------------------------------------------------ consultas
    @property
    def vazia(self) -> bool:
        return not any(d.tipo in NIVEIS_CITAVEIS for d in self.dispositivos)

    def citaveis(self) -> list[DispositivoEstruturado]:
        return [d for d in self.dispositivos if d.tipo in NIVEIS_CITAVEIS]

    def indice(self) -> list[tuple[str, str, bool]]:
        """(referencia, resumo, citacao) de cada dispositivo citável — vai para os prompts."""
        return [(d.referencia, d.resumo, d.citacao) for d in self.dispositivos if d.tipo in NIVEIS_CITAVEIS or d.tipo == "citacao"]

    def candidatos_vigencia(self) -> list[DispositivoEstruturado]:
        cands = [d for d in self.citaveis() if not d.citacao and RE_VIGENCIA.search(d.texto)]
        pre = [d for d in self.dispositivos if d.tipo == "preambulo" and RE_VIGENCIA.search(d.texto)]
        return pre + cands

    def revogacoes(self) -> list[DispositivoEstruturado]:
        return [d for d in self.citaveis() if not d.citacao and RE_REVOGA.search(d.texto)]

    def alteracoes(self) -> list[DispositivoEstruturado]:
        return [d for d in self.citaveis() if not d.citacao and RE_ALTERA.search(d.texto)]

    def verificar_referencia(self, ref: str) -> str:
        """'exata' | 'parcial' (prefixo de/para um dispositivo real) | 'inexistente'."""
        alvo = normalizar_referencia(ref)
        if not alvo:
            return "inexistente"
        existentes = {normalizar_referencia(d.referencia) for d in self.citaveis()}
        if alvo in existentes:
            return "exata"
        if any(e.startswith(alvo + "|") or alvo.startswith(e + "|") for e in existentes if e):
            return "parcial"
        return "inexistente"

    def texto_de(self, ref: str) -> str:
        alvo = normalizar_referencia(ref)
        partes = [d.texto for d in self.citaveis()
                  if normalizar_referencia(d.referencia) == alvo
                  or normalizar_referencia(d.referencia).startswith(alvo + "|")]
        return "\n".join(partes)

    def contem_trecho(self, trecho: str, ref: str | None = None) -> bool:
        alvo = _norm_texto(trecho)
        if len(alvo) < 8:
            return False
        base = _norm_texto(self.texto_de(ref)) if ref else ""
        if base and alvo in base:
            return True
        return alvo in _norm_texto("\n".join(d.texto for d in self.dispositivos))

    def para_markdown(self) -> str:
        linhas = []
        for d in self.dispositivos:
            if d.tipo == "divisao" or d.tipo == "anexo":
                linhas.append(f"\n## {d.texto}\n")
            elif d.tipo == "preambulo":
                linhas.append(d.texto + "\n")
            elif d.tipo == "artigo":
                linhas.append(f"\n**{d.referencia}** {d.texto}")
            elif d.tipo == "citacao":
                linhas.append("> [CITAÇÃO — redação dada a outra norma] " + d.texto.replace("\n", "\n> "))
            elif d.tipo == "rodape":
                linhas.append(f"_{d.texto}_")
            else:
                linhas.append(f"  - **{d.referencia.split(', ')[-1]}** {d.texto}")
        return "\n".join(linhas).strip()


# ---------------------------------------------------------------- normalização
def normalizar_referencia(ref: str) -> str:
    """
    Forma canônica por componentes, separados por '|': "Art. 2º, § 2º, inciso I" -> "art2|§2|incisoi".
    Tolera "art. 2o", "artigo 2", "par. único", "inc. III", "al. b", "caput", ausência de vírgulas.
    """
    s = (ref or "").lower().strip()
    s = re.sub(r"(\d)\s*[ºo°ª]", r"\1", s)                      # 5º / 5o -> 5
    s = re.sub(r"\bartigo\b|\bart\.?", "art", s)
    s = re.sub(r"par[áa]grafo\s+[úu]nico|par\.?\s*[úu]nico|§\s*[úu]nico", "§unico", s)
    s = re.sub(r"par[áa]grafo|\bpar\.", "§", s)
    s = re.sub(r"\binc\.?\b", "inciso", s)
    s = re.sub(r"\bal\.?\b|al[íi]nea", "alinea", s)
    s = re.sub(r"\(texto citado\)", "", s)
    s = re.sub(r"\s*(§|inciso|alinea|item|anexo|art)", r", \1", s)   # garante um componente por nível
    comps = [re.sub(r"[^a-z0-9§]+", "", c) for c in re.split(r"[,;]", s)]
    comps = [c for c in comps if c and c not in ("caput", "do", "da", "o", "a")]
    return "|".join(comps)


def _ordinal(numero: str) -> str:
    """Convenção legislativa: 1º a 9º levam ordinal; de 10 em diante, cardinal."""
    return f"{int(numero)}º" if int(numero) < 10 else str(int(numero))


def _norm_texto(t: str) -> str:
    t = (t or "").lower().replace("“", "").replace("”", "").replace('"', "").replace("’", "'")
    return re.sub(r"\s+", " ", t).strip()


# ------------------------------------------------------------------- parser
def parsear(texto: str) -> EstruturaNorma:
    est = EstruturaNorma()
    ctx = {"anexo": None, "artigo": None, "paragrafo": None, "inciso": None, "alinea": None}
    ids = {"artigo": None, "paragrafo": None, "inciso": None, "alinea": None}
    numeros_artigos: list[int] = []
    em_citacao, citacao_atual, rodape, atual = False, None, False, None
    pre: list[str] = []
    viu_artigo = False

    def novo(tipo, ref, txt, pai=None, citacao=False) -> DispositivoEstruturado:
        d = DispositivoEstruturado(f"d{len(est.dispositivos) + 1:04d}", tipo, ref, txt.strip(), pai, None, citacao)
        est.dispositivos.append(d)
        return d

    def prefixo() -> str:
        return f"Anexo {ctx['anexo']}, " if ctx["anexo"] else ""

    for bruta in texto.splitlines():
        linha = bruta.strip()
        if not linha:
            continue

        # Dentro de um bloco citado: tudo é texto da OUTRA norma.
        if em_citacao:
            citacao_atual.texto += ("\n" if citacao_atual.texto else "") + linha
            if RE_CITACAO_FIM.search(linha):
                em_citacao, citacao_atual = False, None
            continue

        m_div, m_anx = RE_DIVISAO.match(linha), RE_ANEXO.match(linha)
        m_art = RE_ARTIGO.match(linha)

        # Título em caixa alta logo após "CAPÍTULO I" / "ANEXO I" é o nome da divisão.
        if atual is not None and atual.tipo in ("divisao", "anexo") and not (m_art or m_div or m_anx) \
                and RE_NOME_CAIXA_ALTA.match(linha):
            atual.texto += " — " + linha
            continue

        if m_anx and not m_art:
            ctx.update(anexo=(m_anx.group(1) or "único"), artigo=None, paragrafo=None, inciso=None, alinea=None)
            atual, rodape = novo("anexo", f"Anexo {ctx['anexo']}", linha), False
            continue
        if m_div:
            atual = novo("divisao", linha.split(" -")[0].strip(), linha)
            continue
        if m_art:
            viu_artigo, rodape = True, False
            sufixo = (m_art.group(2) or "").replace(" ", "")          # "-A" em "Art. 2º-A"
            ref = f"{prefixo()}Art. {_ordinal(m_art.group(1))}{sufixo}"
            ctx.update(artigo=ref, paragrafo=None, inciso=None, alinea=None)
            atual = novo("artigo", ref, m_art.group(3))
            ids.update(artigo=atual.id, paragrafo=None, inciso=None, alinea=None)
            if not ctx["anexo"]:
                numeros_artigos.append(int(m_art.group(1)))
        elif not viu_artigo:
            pre.append(linha)
            continue
        elif rodape or RE_RODAPE.match(linha) or (RE_NOME_CAIXA_ALTA.match(linha) and not RE_INCISO.match(linha)):
            rodape = True
            atual = novo("rodape", "Rodapé", linha)
            continue
        elif (m := RE_PARAGRAFO.match(linha)):
            ref = f"{ctx['artigo']}, § {_ordinal(m.group(1))}"
            ctx.update(paragrafo=ref, inciso=None, alinea=None)
            atual = novo("paragrafo", ref, m.group(2), ids["artigo"])
            ids.update(paragrafo=atual.id, inciso=None, alinea=None)
        elif (m := RE_PAR_UNICO.match(linha)):
            ref = f"{ctx['artigo']}, parágrafo único"
            ctx.update(paragrafo=ref, inciso=None, alinea=None)
            atual = novo("paragrafo_unico", ref, m.group(1), ids["artigo"])
            ids.update(paragrafo=atual.id, inciso=None, alinea=None)
        elif (m := RE_INCISO.match(linha)):
            base = ctx["paragrafo"] or ctx["artigo"]
            ref = f"{base}, inciso {m.group(1)}"
            ctx.update(inciso=ref, alinea=None)
            atual = novo("inciso", ref, m.group(2), ids["paragrafo"] or ids["artigo"])
            ids.update(inciso=atual.id, alinea=None)
        elif (m := RE_ALINEA.match(linha)) and ctx["inciso"]:
            ref = f"{ctx['inciso']}, alínea {m.group(1)}"
            ctx.update(alinea=ref)
            atual = novo("alinea", ref, m.group(2), ids["inciso"])
            ids.update(alinea=atual.id)
        elif (m := RE_ITEM.match(linha)) and ctx["alinea"]:
            atual = novo("item", f"{ctx['alinea']}, item {m.group(1)}", m.group(2), ids["alinea"])
        elif atual is not None:
            atual.texto += " " + linha        # continuação do dispositivo anterior
        else:
            pre.append(linha)

        # A linha recém-tratada anuncia um bloco de redação citada?
        if atual is not None and atual.tipo != "citacao" and RE_CITACAO_INICIO.search(linha) \
                and not RE_CITACAO_FIM.search(linha):          # citação inteira na mesma linha: nada a abrir
            em_citacao = True
            citacao_atual = novo("citacao", f"{atual.referencia} (texto citado)", "", atual.id, True)

    if pre:
        est.dispositivos.insert(0, DispositivoEstruturado("d0000", "preambulo", "Preâmbulo", "\n".join(pre)))
    if em_citacao:
        est.avisos.append("Bloco de redação citada sem marcador de fim ((NR), (AC) ou aspas).")
    if not viu_artigo:
        est.avisos.append("Nenhum artigo reconhecido: texto sem estrutura LC 95 ou extração falhou.")
    for a, b in zip(numeros_artigos, numeros_artigos[1:]):
        if b <= a:
            est.avisos.append(f"Numeração de artigos não crescente: Art. {a} seguido de Art. {b}.")
        elif b - a > 1:
            est.avisos.append(f"Lacuna na numeração: Art. {a} -> Art. {b} (artigos revogados ou perda na extração).")
    return est
